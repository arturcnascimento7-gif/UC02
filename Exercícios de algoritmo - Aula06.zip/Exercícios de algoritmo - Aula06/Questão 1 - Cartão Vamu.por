programa {
  funcao inicio() {
    real saldoAtual, valorDaPassagem, saldoFinal

    escreva("Informe o saldo atual: ", "\n")
    leia(saldoAtual)

   escreva("Informe o valor da passagem: ", "\n")
   leia(valorDaPassagem)
   saldoFinal = saldoAtual - valorDaPassagem

   escreva("O saldo final do cartão é de: ", saldoFinal)

  }
}
