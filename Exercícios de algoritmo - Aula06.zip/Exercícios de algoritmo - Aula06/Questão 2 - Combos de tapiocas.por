programa {
  funcao inicio() {
    
  real  quantidade, valorTotal
  const real combo1 = 35.50
 
  escreva("Quantas unidades você vai querer? ", "\n")
  leia(quantidade)

  valorTotal = combo1 * quantidade
 escreva("O valor final da compra será: ", valorTotal)
  }
}
