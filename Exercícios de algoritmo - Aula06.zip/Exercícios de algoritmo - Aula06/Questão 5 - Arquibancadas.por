programa {
  funcao inicio() {
    
    inteiro numero1
    inteiro numero2   

   escreva("Qual o número de torcedores que sentarão nas arquibancadas? ", "\n")
   leia(numero1)

   escreva("Qual o número de torcedores que sentarão nas cadeiras especias? ", "\n")
   leia(numero2)

   escreva("O público total de torcedores no estádio é: ", numero1 + numero2)

  }
}
