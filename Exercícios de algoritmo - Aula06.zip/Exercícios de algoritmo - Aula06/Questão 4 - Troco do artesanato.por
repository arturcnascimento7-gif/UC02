programa {
  funcao inicio() {
    
    real valor1, valor2

    escreva("Qual o valor do souvenir? ", "\n")
    leia(valor1)

   escreva("Qual o valor que você entregou? ", "\n")
   leia(valor2)

   escreva("O troco a receber é: ", valor2 - valor1)


  }
}
