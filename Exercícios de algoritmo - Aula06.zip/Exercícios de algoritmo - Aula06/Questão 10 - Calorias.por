programa {
  funcao inicio() {
    
    real calorias1, calorias2


  escreva("Quantas calorias tem no salgado assado? ", "\n")
  leia(calorias1)

  escreva("Qual a quantidade de calorias em suco de fruta? ", "\n")
  leia(calorias2)

  escreva("A caloria total dos lanches foi: ", calorias1 + calorias2)

  }
}
