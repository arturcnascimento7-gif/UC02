programa {
  funcao inicio() {
    
    real valor1, valorFinal

   escreva("Qual o valor do pote de açaí? ", "\n")
   leia(valor1)

   valorFinal = valor1 / 3
   
   escreva("O valor a ser pago por cada aluno será: ", valorFinal)

  }
}
