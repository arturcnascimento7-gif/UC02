programa {
  funcao inicio() {
    real valor1, totalDeCada

    escreva("Qual o valor do passeio? ", "\n")
    leia(valor1)
    
   totalDeCada = valor1 / 4

   escreva("Cada um deve pagar ", totalDeCada)

  }
}
