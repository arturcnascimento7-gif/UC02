programa {
  funcao inicio() {
    
   real valor1, desconto
   
   escreva("Qual o valor do pote de sorvete de 1 litro? ", "\n")
   leia(valor1)

   escreva("Quantos reais de desconto você recebeu? ", "\n")
   leia(desconto)

  escreva("O preço final do sorvete de 1 litro, com desconto foi: ", valor1 - desconto)

  }
}
