programa {
  funcao inicio() {
    
    inteiro carga1, tempo, tempoFinal
    
    escreva("Qual a porcentagem atual do celular? ", "\n")
    leia(carga1)

    se (carga1 >= 0 e carga1 <=99){   
    }
  senao 
{
    escreva("Carga inválida", "\n")
    retorne
}

    escreva("Qual o tempo medio para carregar 1% de bateria?(em minutos) ", "\n")
    leia(tempo)
  
    tempoFinal = (carga1 + 100)*tempo

    escreva("O tempo medio(em minutos) para a carga máxima é ", tempoFinal)

    

  }
}
