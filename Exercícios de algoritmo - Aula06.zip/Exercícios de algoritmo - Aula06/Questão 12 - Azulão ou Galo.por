programa {
  funcao inicio() {
    
    real vitoria, pontuacaoFinal

   escreva("Quantas vitórias o seu time do coração teve? ", "\n")
   leia(vitoria)

   pontuacaoFinal = vitoria * 3

   escreva("Pontuação final acumulada pelo time foi: ", pontuacaoFinal)


  }
}
