programa {
  funcao inicio() {
    
    inteiro vendidos, valorFinal

    escreva("Quantos picolés foram vendidos ao final do dia? ", "\n")
    leia(vendidos)

    valorFinal = vendidos * 2

    escreva("Ao final do dia ele receberá o valor de: ", valorFinal)

  }
}
