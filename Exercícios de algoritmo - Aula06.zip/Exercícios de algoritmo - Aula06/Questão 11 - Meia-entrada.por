programa {
  funcao inicio() {
    
    real valor1, estudantes, meiaEntrada

   escreva("Qual o valor do ingresso inteiro? ", "\n")
   leia(valor1)

   escreva("Quantos estudantes vão ao cinema? ","\n")
   leia(estudantes)

   meiaEntrada = valor1 * estudantes / 2

   escreva("O custo total a ser pago é: ", meiaEntrada)

  }
}
