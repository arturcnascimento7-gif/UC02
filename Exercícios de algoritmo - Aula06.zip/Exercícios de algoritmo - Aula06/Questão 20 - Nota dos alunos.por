programa {
  funcao inicio() {
    
    real nota1, nota2, notaFinal

  escreva("Qual a nota da primeira avaliação? ", "\n")
  leia(nota1)

se (nota1 >=0 e nota1 <=10){

}
senao
{
  escreva("Nota inválida")
  retorne
}

 escreva("Qual a nota da segunda avaliação? ", "\n")
 leia(nota2)

se (nota2 >=0 e nota2 <=10){

}
senao
{
  escreva("Nota inválida")
  retorne
}

  notaFinal = (nota1 + nota2) / 2

escreva("A nota final do aluno será: ", notaFinal)

  }
}
