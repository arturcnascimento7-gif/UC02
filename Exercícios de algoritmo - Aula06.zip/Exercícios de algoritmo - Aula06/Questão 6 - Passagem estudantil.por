programa {
  funcao inicio() {
    
    real custo, custoTotal

   escreva("Qual o custo unitário da passagem estudantil? ", "\n")
   leia(custo)

   custoTotal = custo * 40

   escreva("O custo total mensal necessário para 40 passagens é: ", custoTotal)

  }
}
