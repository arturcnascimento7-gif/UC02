programa {
  funcao inicio() {
    
  real distancia1, velocidade, tempoTotal
  
  escreva("Qual a distância a ser percorrida?(em metros) ", "\n")
  leia(distancia1)

  escreva("Qual a velocidade da pedalada?(em metros por segundo) ", "\n")
  leia(velocidade)

  tempoTotal = distancia1 / velocidade
 
  escreva("O tempo total estimado da viagem em minutos é: ", tempoTotal)

  }
}
