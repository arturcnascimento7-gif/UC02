programa {
  funcao inicio() {
    
  real distancia1, litros1, final

  escreva("Qual a distância percorrido até Marechal?(em quilômetros) ", "\n")
  leia(distancia1)

  escreva("Qual a quantidade de combustivel usado no trajeto?(em litros) ", "\n")
  leia(litros1)

  final = distancia1 / litros1

  escreva("Ele percorreu ", final, " quilômetros por litro. ")


  }
}
