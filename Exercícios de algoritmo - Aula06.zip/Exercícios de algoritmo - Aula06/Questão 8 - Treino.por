programa {
  funcao inicio() {
    
  real distancia1, distanciaTotal

 escreva("Qual distância percorrida na ida?(em metros)", "\n")
 leia(distancia1)

 distanciaTotal = distancia1 + distancia1


  escreva("A distância total percorrida é: ", distanciaTotal)


  }
}
